#!/usr/bin/env bash
set -Eeuo pipefail

require() { command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1" >&2; exit 2; }; }
ask() { local p="$1" d="$2" v; read -r -p "$p [$d]: " v; printf '%s' "${v:-$d}"; }

[[ $EUID -eq 0 ]] || { echo 'Run as root on Proxmox VE.' >&2; exit 1; }
require qm; require pvesm; require curl; require sha256sum
pveversion >/dev/null

VMID=$(ask 'Template VMID' '9000')
NAME=$(ask 'Template name' 'ubuntu-2404-cloud-template')
STORAGE=$(ask 'Storage for VM disks/cloud-init' 'local-lvm')
BRIDGE=$(ask 'Default bridge' 'vmbr0')
IMAGE_DIR=/var/lib/vz/template/iso
IMAGE=noble-server-cloudimg-amd64.img
BASE=https://cloud-images.ubuntu.com/noble/current
mkdir -p "$IMAGE_DIR"

if qm status "$VMID" >/dev/null 2>&1; then
  echo "VMID $VMID already exists. Refusing to overwrite." >&2
  exit 3
fi

printf '\nDownloading Ubuntu 24.04 LTS cloud image...\n'
curl -fL --retry 4 --retry-delay 3 "$BASE/$IMAGE" -o "$IMAGE_DIR/$IMAGE.part"
curl -fL --retry 4 "$BASE/SHA256SUMS" -o "$IMAGE_DIR/SHA256SUMS.noble"
mv "$IMAGE_DIR/$IMAGE.part" "$IMAGE_DIR/$IMAGE"
(
  cd "$IMAGE_DIR"
  grep "  \*\?$IMAGE$" SHA256SUMS.noble | sed 's/ \*/  /' | sha256sum -c -
)

qm create "$VMID" \
  --name "$NAME" \
  --ostype l26 \
  --machine q35 \
  --cpu x86-64-v2-AES \
  --cores 2 \
  --memory 2048 \
  --balloon 0 \
  --scsihw virtio-scsi-single \
  --net0 "virtio,bridge=$BRIDGE" \
  --agent 'enabled=1,fstrim_cloned_disks=1' \
  --serial0 socket \
  --vga serial0

qm importdisk "$VMID" "$IMAGE_DIR/$IMAGE" "$STORAGE"
VOL=$(qm config "$VMID" | awk '/^unused0:/ {sub(/^unused0:[[:space:]]*/,""); print; exit}')
[[ -n "$VOL" ]] || { echo 'Imported disk not found as unused0.' >&2; qm destroy "$VMID" --purge 1; exit 4; }
qm set "$VMID" --delete unused0
qm set "$VMID" --scsi0 "$VOL,discard=on,ssd=1,iothread=1"
qm set "$VMID" --ide2 "$STORAGE:cloudinit"
qm set "$VMID" --boot 'order=scsi0;ide2'
qm set "$VMID" --citype nocloud
qm set "$VMID" --ciupgrade 0
qm template "$VMID"

echo
qm config "$VMID"
echo
printf 'Template %s (%s) created.\n' "$VMID" "$NAME"
printf 'Next: ./create-vm.sh\n'

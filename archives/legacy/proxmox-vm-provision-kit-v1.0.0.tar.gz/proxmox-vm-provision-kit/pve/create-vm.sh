#!/usr/bin/env bash
set -Eeuo pipefail

ask() { local p="$1" d="$2" v; read -r -p "$p [$d]: " v; printf '%s' "${v:-$d}"; }
yesno() { local p="$1" d="${2:-y}" v; read -r -p "$p [$([[ $d == y ]] && echo Y/n || echo y/N)]: " v; v="${v:-$d}"; [[ "$v" =~ ^[YyДд] ]]; }
menu_role() {
  cat >&2 <<'EOT'
Роль VM:
  1 edge             2 web              3 gitlab
  4 gitlab-runner    5 planka           6 telemetry
  7 fileserver       8 nextcloud        9 sftpgo
 10 mailcow          11 monitoring      12 vaultwarden
EOT
  local n; read -r -p 'Номер: ' n
  case "$n" in
    1) echo edge;; 2) echo web;; 3) echo gitlab;; 4) echo gitlab-runner;;
    5) echo planka;; 6) echo telemetry;; 7) echo fileserver;; 8) echo nextcloud;;
    9) echo sftpgo;; 10) echo mailcow;; 11) echo monitoring;; 12) echo vaultwarden;;
    *) echo 'Invalid role' >&2; exit 2;;
  esac
}
profile() {
  case "$1" in
    edge) echo '2 2048 24';;
    web) echo '4 8192 80';;
    gitlab) echo '8 16384 160';;
    gitlab-runner) echo '8 16384 100';;
    planka) echo '2 4096 40';;
    telemetry) echo '8 32768 160';;
    fileserver) echo '4 8192 40';;
    nextcloud) echo '4 8192 80';;
    sftpgo) echo '2 4096 40';;
    mailcow) echo '8 16384 160';;
    monitoring) echo '4 8192 80';;
    vaultwarden) echo '2 2048 24';;
  esac
}

[[ $EUID -eq 0 ]] || { echo 'Run as root on Proxmox VE.' >&2; exit 1; }
command -v qm >/dev/null || exit 2
ROLE=$(menu_role)
read -r DEF_CORES DEF_RAM DEF_DISK <<<"$(profile "$ROLE")"
TEMPLATE=$(ask 'Ubuntu 24.04 cloud template VMID' '9000')
VMID=$(ask 'New VMID' '110')
NAME=$(ask 'VM name' "$ROLE-01")
STORAGE=$(ask 'Target storage' 'local-lvm')
BRIDGE=$(ask 'Bridge' 'vmbr0')
VLAN=$(ask 'VLAN tag (empty = none)' '')
CORES=$(ask 'vCPU' "$DEF_CORES")
RAM=$(ask 'RAM MiB' "$DEF_RAM")
DISK=$(ask 'System disk GiB' "$DEF_DISK")
CIUSER=$(ask 'Cloud-init admin user' 'sysadmin')
SSHKEY=$(ask 'Public SSH key file on Proxmox host' '/root/.ssh/id_ed25519.pub')
NETMODE=$(ask 'Network: dhcp or static' 'static')
if [[ "$NETMODE" == static ]]; then
  IP=$(ask 'IPv4/CIDR' '10.0.30.110/24')
  GW=$(ask 'Gateway' '10.0.30.1')
  IPCONFIG="ip=$IP,gw=$GW"
else
  IPCONFIG='ip=dhcp'
fi
DNS=$(ask 'DNS server' '1.1.1.1')
SEARCH=$(ask 'DNS search domain' 'lan')

[[ -r "$SSHKEY" ]] || { echo "SSH public key not readable: $SSHKEY" >&2; exit 3; }
qm status "$TEMPLATE" >/dev/null 2>&1 || { echo "Template $TEMPLATE not found" >&2; exit 3; }
if qm status "$VMID" >/dev/null 2>&1; then echo "VMID $VMID exists" >&2; exit 3; fi

qm clone "$TEMPLATE" "$VMID" --name "$NAME" --full 1 --storage "$STORAGE"
trap 'echo "Provision failed. VM $VMID remains for inspection." >&2' ERR
NET="virtio,bridge=$BRIDGE,firewall=1"
[[ -n "$VLAN" ]] && NET+=",tag=$VLAN"
qm set "$VMID" \
  --cores "$CORES" --memory "$RAM" --balloon 0 \
  --cpu x86-64-v2-AES --numa 1 \
  --net0 "$NET" \
  --agent 'enabled=1,fstrim_cloned_disks=1' \
  --ciuser "$CIUSER" \
  --sshkeys "$SSHKEY" \
  --ipconfig0 "$IPCONFIG" \
  --nameserver "$DNS" \
  --searchdomain "$SEARCH" \
  --tags "ubuntu24;service;$ROLE"
qm resize "$VMID" scsi0 "${DISK}G"
qm set "$VMID" --onboot 1 --startup 'order=20,up=30,down=60'

# For data-heavy roles, remind about a separate data disk instead of bloating root.
case "$ROLE" in
  telemetry|fileserver|nextcloud|mailcow|gitlab)
    echo "NOTE: $ROLE should receive a separate data disk/dataset where appropriate." >&2
    ;;
esac

qm start "$VMID"
echo
qm config "$VMID"
echo
printf 'VM %s (%s) started. Wait for cloud-init, then copy guest/ and run:\n' "$VMID" "$NAME"
printf '  sudo ./setup.sh --role %s\n' "$ROLE"
printf 'Keep the Proxmox console open while SSH port is changed.\n'

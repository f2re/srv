#!/usr/bin/env bash
set -Eeuo pipefail

usage() {
  cat <<'EOT'
Usage:
  ./deploy-role.sh HOST ROLE [USER] [SSH_PORT] [SSH_KEY]

Example:
  ./deploy-role.sh 10.0.30.120 gitlab sysadmin 22 ~/.ssh/id_ed25519

ROLE: edge|web|gitlab|gitlab-runner|planka|telemetry|fileserver|nextcloud|sftpgo|mailcow|monitoring|vaultwarden

Скрипт копирует guest provisioning-kit на уже созданную Ubuntu VM и запускает
интерактивный мастер через SSH. Текущая SSH-сессия останется открыта, даже когда
base.sh переключит sshd на новый порт; держите Proxmox Console открытой.
EOT
}

[[ $# -ge 2 ]] || { usage; exit 2; }
HOST="$1"; ROLE="$2"; USER="${3:-sysadmin}"; PORT="${4:-22}"; KEY="${5:-$HOME/.ssh/id_ed25519}"
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GUEST="$BASE_DIR/guest"
[[ -d "$GUEST" ]] || { echo "guest/ не найден: $GUEST" >&2; exit 2; }
[[ -r "$KEY" ]] || { echo "SSH key не найден: $KEY" >&2; exit 2; }

case "$ROLE" in
  edge|web|gitlab|gitlab-runner|planka|telemetry|fileserver|nextcloud|sftpgo|mailcow|monitoring|vaultwarden) ;;
  *) echo "Неизвестная роль: $ROLE" >&2; usage; exit 2 ;;
esac

SSH=(ssh -tt -p "$PORT" -i "$KEY" -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30 "$USER@$HOST")
SCP=(scp -P "$PORT" -i "$KEY" -o StrictHostKeyChecking=accept-new)
TMP="infra-provision-$(date +%s).tar.gz"
trap 'rm -f "/tmp/$TMP"' EXIT

tar -C "$BASE_DIR" -czf "/tmp/$TMP" guest
printf 'Копирование provisioning-kit на %s...\n' "$HOST"
"${SCP[@]}" "/tmp/$TMP" "$USER@$HOST:/tmp/$TMP"

printf '\nЗапуск интерактивной настройки роли %s...\n' "$ROLE"
"${SSH[@]}" "sudo rm -rf /opt/infra-provision-kit && sudo mkdir -p /opt/infra-provision-kit && sudo tar -xzf /tmp/$TMP -C /opt/infra-provision-kit --strip-components=1 && sudo chmod -R go-rwx /opt/infra-provision-kit && sudo chmod +x /opt/infra-provision-kit/setup.sh /opt/infra-provision-kit/base.sh /opt/infra-provision-kit/roles/*.sh && cd /opt/infra-provision-kit && sudo ./setup.sh --role '$ROLE'"

#!/usr/bin/env bash
# shellcheck shell=bash
: "${PVE_PROVISION_LOG:=/var/log/infra-pve-provision.log}"

pve_log() { printf '%s [%s] %s\n' "$(date --iso-8601=seconds)" "$1" "$2" | tee -a "$PVE_PROVISION_LOG" >&2; }
ask() { local p="$1" d="$2" v; read -r -p "$p [$d]: " v || return 1; printf '%s' "${v:-$d}"; }
yesno() { local p="$1" d="${2:-y}" v; read -r -p "$p [$([[ $d == y ]] && echo Y/n || echo y/N)]: " v || return 1; v="${v:-$d}"; [[ "$v" =~ ^[YyДд] ]]; }
menu() {
  local title="$1"; shift; local -a a=("$@"); local i v
  printf '\n== %s ==\n' "$title" >&2
  for ((i=0;i<${#a[@]};i+=2)); do printf '  %s) %s\n' "${a[i]}" "${a[i+1]}" >&2; done
  while true; do
    read -r -p 'Выбор: ' v || return 1
    for ((i=0;i<${#a[@]};i+=2)); do [[ "$v" == "${a[i]}" ]] && { printf '%s' "$v"; return 0; }; done
  done
}

pve_run() {
  local label="$1"; shift; local rc action
  while true; do
    pve_log INFO "START: $label"
    if "$@" >>"$PVE_PROVISION_LOG" 2>&1; then
      pve_log INFO "OK: $label"; return 0
    else
      rc=$?
    fi
    pve_log ERROR "FAILED($rc): $label"
    action=$(menu "Ошибка: $label" r 'Повторить шаг' l 'Показать последние 60 строк лога' s 'Открыть shell для диагностики' a 'Прервать') || return "$rc"
    case "$action" in
      r) continue;;
      l) tail -n 60 "$PVE_PROVISION_LOG" >&2;;
      s) echo 'После диагностики выполните exit.' >&2; bash -l;;
      a|*) return "$rc";;
    esac
  done
}

pve_run_interactive() {
  local label="$1"; shift; local rc action
  while true; do
    pve_log INFO "START interactive: $label"
    if "$@" > >(tee -a "$PVE_PROVISION_LOG") 2> >(tee -a "$PVE_PROVISION_LOG" >&2); then
      pve_log INFO "OK interactive: $label"
      return 0
    else
      rc=$?
    fi
    pve_log ERROR "FAILED($rc) interactive: $label"
    action=$(menu "Ошибка: $label" r 'Повторить' l 'Показать последние 60 строк лога' s 'Открыть shell' a 'Прервать') || return "$rc"
    case "$action" in
      r) continue;; l) tail -n 60 "$PVE_PROVISION_LOG" >&2;; s) bash -l;; a|*) return "$rc";;
    esac
  done
}

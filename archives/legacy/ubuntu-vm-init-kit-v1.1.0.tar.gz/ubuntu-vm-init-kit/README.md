# Ubuntu VM Init Kit

Комплект запускается **внутри уже созданной виртуальной машины**. Proxmox нужен только для создания VM, подключения консоли, дисков и сетей. Скрипты `qm`, cloud-init и управление гипервизором сюда не входят.

## Рекомендуемая ОС

Для унифицированной production-инфраструктуры используйте **Ubuntu Server 24.04 LTS amd64**. Ubuntu 26.04 LTS уже является актуальной LTS, но GitLab Linux package официально перечисляет Ubuntu 20.04/22.04/24.04; поэтому 24.04 остаётся безопасной общей базой для GitLab, GitLab Runner, Mailcow/Docker и остальных VM.

## Быстрый запуск

1. Создайте VM в Proxmox и установите Ubuntu Server 24.04 LTS.
2. Убедитесь, что VM имеет сеть и DNS.
3. Передайте архив на VM и распакуйте.
4. Запустите:

```bash
cd ubuntu-vm-init-kit
sudo ./vm-setup.sh
```

При первом запуске каталог скриптов копируется в `/opt/infra-vm-init-kit`, после чего мастер продолжает работу оттуда.

Можно сразу выбрать роль:

```bash
sudo ./vm-setup.sh --role gitlab
sudo ./vm-setup.sh --role gitlab-runner
sudo ./vm-setup.sh --role mailcow
sudo ./vm-setup.sh --role nextcloud
```

Или использовать отдельные понятные точки входа:

```bash
sudo ./install-gitlab.sh
sudo ./install-gitlab-runner.sh
sudo ./install-web.sh
sudo ./install-mailcow.sh
sudo ./install-planka.sh
sudo ./install-telemetry.sh
sudo ./install-fileserver.sh
sudo ./install-nextcloud.sh
sudo ./install-sftpgo.sh
sudo ./install-monitoring.sh
sudo ./install-edge.sh
sudo ./install-vaultwarden.sh
```

## Что делает базовая подготовка

Перед установкой выбранной роли мастер:

- обновляет Ubuntu;
- устанавливает QEMU Guest Agent;
- устанавливает и настраивает OpenSSH Server;
- предлагает изменить SSH-порт (по умолчанию 2222);
- запрещает root SSH;
- отключает password authentication только если найден `authorized_keys`;
- ставит Fail2Ban для SSH;
- включает unattended security updates;
- устанавливает AppArmor/auditd и консервативные sysctl-параметры;
- настраивает время/NTP;
- устанавливает rsync/ACL/xattr/Git/curl/jq/tmux/htop/btop и диагностические утилиты;
- предлагает Fish + Oh My Fish;
- предлагает безопасно подключить отдельный data-диск для stateful-сервисов;
- сохраняет журнал и состояние для безопасного повторного запуска.

Если на свежей Ubuntu имеется только root, мастер предложит создать отдельного sudo-администратора.

## Ошибки

Критические операции выполняются через общий обработчик. При сбое доступны:

- повторить шаг;
- показать журнал;
- открыть аварийный shell;
- прервать установку;
- для необязательных шагов — пропустить.

APT-lock ожидается до 120 секунд, после чего ошибка также попадает в этот обработчик.

Журнал:

```text
/var/log/infra-provision/provision.log
```

Состояние:

```text
/var/lib/infra-provision/
/etc/infra-provision/config.env
```

Повторный мастер:

```bash
sudo /opt/infra-vm-init-kit/vm-setup.sh
```

Проверка:

```bash
sudo /opt/infra-vm-init-kit/healthcheck.sh
```

## Firewall и Docker

Для обычных host-сервисов мастер предлагает UFW `deny incoming` и открывает только SSH/порты роли.

Для Mailcow/Nextcloud/PLANKA/SFTPGo/Vaultwarden рекомендуется внешний firewall Proxmox/маршрутизатора: опубликованные Docker-порты нельзя считать надёжно закрытыми только правилами UFW.

## PMG

Proxmox Mail Gateway не является Ubuntu-приложением этого комплекта. Для PMG используйте отдельную VM на поддерживаемой Debian/официальном PMG ISO. Почтовый сервер Mailcow устанавливается штатной Ubuntu-ролью.

## Следующий этап миграции

После подготовки целевой VM этим комплектом используйте `infrastructure-migration-kit` для переноса данных и настроек со старой VDS на новую VM. Сначала provisioning, затем пробное восстановление, затем финальный cutover.

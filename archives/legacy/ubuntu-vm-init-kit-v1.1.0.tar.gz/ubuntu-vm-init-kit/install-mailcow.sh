#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec ./vm-setup.sh --role mailcow

# Комплект управляемой миграции инфраструктуры

Комплект переносит сервисы со старых VDS/серверов в отдельные VM на Proxmox по схеме:

```text
источник → штатный прикладной backup → контроллер → локальный staging
          → контрольные суммы → целевая VM → restore → проверка
```

Контроллер **не переключает DNS, NAT, MX или публичный reverse proxy**. Сначала целевая VM восстанавливается и проверяется в изолированной сети. Публичное переключение выполняется отдельным явным действием после приёмки.

## Поддерживаемые модули

- Nginx/HAProxy и сертификаты;
- сайт или служба systemd/Docker, PostgreSQL или MySQL/MariaDB;
- GitLab CE/EE Linux package и GitLab Runner;
- Planka Docker Compose;
- телеметрия с PostgreSQL/MySQL либо пользовательскими штатными командами backup/restore;
- Samba/NFS/SFTPGo и большие файловые каталоги с ACL/xattr;
- инкрементальная предварительная синхронизация больших каталогов через `staged_paths`;
- Nextcloud с БД, `config`, приложениями, темами и каталогом данных;
- Mailcow через официальный `backup_and_restore.sh`;
- Proxmox Mail Gateway через `pmgbackup`;
- Prometheus/Grafana/Alertmanager/Loki как обычная служба с данными и конфигурацией;
- старый Postfix/Dovecot как точный перенос той же схемы;
- переход Postfix/Dovecot → Mailcow через отдельную карту доменов/ящиков/алиасов и повторяемый IMAP-перенос.

## Состав

```text
orchestrator.py             контроллер миграции
remote_agent.py             агент источника/цели
inventory.example.json      полный пример инфраструктуры
bootstrap-node.sh           временный SSH-доступ на узле
cleanup-node.sh             удаление временного доступа
check-controller.sh         проверка управляющего компьютера
mail-migration/             переход старой почты в Mailcow
docs/                       регламент, матрица и промпт для агента
```

## Требования

Контроллер:

- Linux/macOS или административная VM;
- Python 3.8+;
- OpenSSH, `rsync`, GNU `tar`;
- Linux-контроллер с файловой системой, поддерживающей user xattr;
- достаточно локального места для staging самого большого сервиса или большого каталога из `staged_paths`.

Источник и цель:

- Python 3;
- `rsync`, GNU `tar`, ACL/xattr;
- штатные утилиты конкретного приложения;
- SSH-ключ и временный пользователь `migration`.

## 1. Подготовка контроллера

```bash
cp inventory.example.json inventory.json
nano inventory.json
./check-controller.sh
```

В `inventory.json` замените адреса, пути, systemd units, имена БД и проверки доступности. Пароли в inventory не помещайте. Для БД используйте peer-аутентификацию, `.pgpass` или `--defaults-extra-file` с правами `0600`.

## 2. Подготовка каждого источника и каждой целевой VM

На контроллере создайте отдельный ключ:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/migration_ed25519 -C migration-controller
```

На каждом сервере от root:

```bash
sudo ./bootstrap-node.sh \
  --authorized-key-file /root/migration_ed25519.pub \
  --user migration
```

Скрипт не выдаёт буквальный `NOPASSWD: ALL`, но разрешает привилегированные операции агента и `rsync`. На время миграции этот SSH-ключ следует считать эквивалентным root-доступу; после приёмки его обязательно удалить через `cleanup-node.sh`.

## 3. Установка агента и создание запуска

```bash
./orchestrator.py --inventory inventory.json bootstrap

RUN=20260804-migration-01
./orchestrator.py --inventory inventory.json --run "$RUN" init-run
./orchestrator.py --inventory inventory.json --run "$RUN" plan
```

Файл `migration-runs/$RUN/state.json` содержит одноразовые защитные токены. Он должен иметь права `0600` и не должен попадать в Git.

## 4. Инвентаризация до копирования

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" validate
./orchestrator.py --inventory inventory.json --run "$RUN" inspect
```

Отчёты появятся в:

```text
migration-runs/$RUN/reports/
```

Сверьте:

- версии ОС и архитектуру;
- версии GitLab CE/EE, PostgreSQL, MySQL, PHP, Docker и Compose;
- реальные пути данных;
- systemd units, cron/timers;
- внешние S3, Redis, LDAP, SMTP и object storage;
- свободное место источника, контроллера и цели;
- UID/GID владельцев файлов;
- доступность цели только во внутренней сети.

После инспекции подготовьте целевые VM с **теми же версиями приложений и совместимыми версиями ОС/БД**. Команды установки можно поместить в `target_options.pre_restore_commands`, но только вместе с `allow_shell_hooks: true` и после ручной проверки.

## 5. Репетиция

Сначала переносите один сервис на изолированную цель:

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" \
  --service planka rehearse
```

`rehearse` выполняет:

1. штатный export на источнике;
2. скачивание на контроллер;
3. загрузку на целевую VM;
4. restore;
5. локальные health checks.

Для GitLab, Nextcloud, сайта и почты целевая VM не должна быть опубликована в DNS и не должна принимать рабочие записи во время репетиции.

## 6. Финальный перенос

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" \
  --service planka cutover
```

`cutover`:

1. останавливает запись на источнике;
2. создаёт финальный backup;
3. скачивает и передаёт bundle;
4. восстанавливает цель;
5. проверяет цель;
6. оставляет старый источник остановленным.

При ошибке до публичного переключения контроллер по умолчанию пытается возобновить источник. Для запрета такого поведения используйте `--no-auto-resume`.

После успешного `cutover` отдельно переключите:

- DNS A/AAAA/CNAME;
- MX и transport PMG;
- NAT/HAProxy;
- webhook URL;
- адреса телеметрии;
- SMTP relay;
- GitLab Runner URL при изменении имени.

Затем выполните внешнюю проверку и только после неё разрешайте запись пользователям.

## 7. Ручные стадии вместо одной команды

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" --service website quiesce
./orchestrator.py --inventory inventory.json --run "$RUN" --service website export
./orchestrator.py --inventory inventory.json --run "$RUN" --service website pull
./orchestrator.py --inventory inventory.json --run "$RUN" --service website push
./orchestrator.py --inventory inventory.json --run "$RUN" --service website restore
./orchestrator.py --inventory inventory.json --run "$RUN" --service website verify
```

Возврат источника до переключения пользователей:

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" --service website resume
```

После появления новых записей на целевой системе простой `resume` старой системы уже не является корректным откатом: потребуется обратная синхронизация или восстановление целевой БД на источник.

## Особенности модулей

### GitLab

Модуль сохраняет:

- штатный GitLab application backup;
- `/etc/gitlab`, включая `gitlab-secrets.json`;
- SSH host keys;
- настраиваемые object-storage paths.

На цели должна быть установлена **точно та же версия и тот же тип CE/EE**. После restore запускаются `gitlab-ctl reconfigure`, `gitlab-ctl restart` и `gitlab-rake gitlab:check SANITIZE=true`.

GitLab Registry, LFS или artifacts во внешнем object storage нужно явно добавить в `object_storage_paths` либо перенести средствами самого object storage.

### Planka

Используются официальные `docker-backup.sh` и `docker-restore.sh`. Они должны присутствовать по путям, указанным в inventory. Приложение останавливается, PostgreSQL остаётся доступной для создания финальной копии.

### Nextcloud

Сохраняются программные файлы, `config`, `custom_apps`, `themes`, каталог данных и БД. По возможности сохраняйте прежний путь `datadirectory`. Значения `secret`, `instanceid` и `serverid` нельзя генерировать заново.

После восстановления можно включить `run_data_fingerprint`. Снятие maintenance mode лучше выполнять после ручной проверки конфигурации Redis, object storage, LDAP и reverse proxy.

### Файловое хранилище

Файлы передаются `rsync -aHAX --numeric-ids --sparse`. По умолчанию целевые лишние файлы **не удаляются**. `delete_target_extra: true` включайте только после сравнительного `rsync --dry-run`.

Конфигурация Samba проверяется через `testparm`. Для NAS-массивов сначала создайте datasets и mountpoints на цели; агент не создаёт ZFS-пулы и не меняет RAID.

### Mailcow

Используется официальный `helper-scripts/backup_and_restore.sh backup all`. Целевой Mailcow должен быть инициализирован и запущен пустым перед restore.

Автоматический интерактивный restore заблокирован, пока в `target_options` не установлено:

```json
"noninteractive_restore": true
```

Перед этим убедитесь, что в bundle ровно один каталог `mailcow-*`. Ключи `crypt` входят в штатную полную копию и обязательны для доступа к зашифрованным ящикам.

Подробный выбор сценария описан в `docs/MAIL_MIGRATION.md`.

Для финального backup Mailcow нельзя просто выполнить `docker compose down`, поскольку штатный helper использует контейнеры. В примере inventory `quiesce_mode=hooks_only`: временное nftables-правило блокирует SMTP/IMAP/Submission, а PMG должен удерживать входящую очередь.

### PMG

`pmgbackup` переносит конфигурацию, правила и статистическую БД. Сетевые настройки, очередь Postfix, карантины и tracking logs в штатный backup не входят. Они помещаются в отдельный reference archive и **не применяются автоматически**.

### Старый Postfix/Dovecot → Mailcow

Нельзя безопасно загрузить произвольные SQL-таблицы и Maildir напрямую в Mailcow. Используйте каталог `mail-migration/`:

1. модуль `legacy_mail` для аварийной копии старого сервера;
2. CSV-карты доменов, ящиков и алиасов;
3. создание пустых ящиков в Mailcow;
4. `mailbox_sync.py` для повторяемого IMAP-переноса;
5. финальный IMAP-проход после запрета записи на старом сервере.

## Сохранение и удаление staging

Архив без шифрования:

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" archive
```

Шифрование через `age`:

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" archive \
  --age-recipient age1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Удалять незашифрованный staging только после проверки архива:

```bash
./orchestrator.py --inventory inventory.json --run "$RUN" archive \
  --age-recipient age1... --purge
```

## Завершение

После 14–30 дней стабильной работы:

```bash
sudo ./cleanup-node.sh migration
```

На источниках оставьте данные read-only до истечения принятого периода отката. Каталог `/var/lib/migkit/runs` скрипт очистки намеренно не удаляет.

## Ограничения

- комплект не знает текущую структуру проекта без `inspect` и корректировки inventory;
- он не создаёт Proxmox VM, VLAN, ZFS pools и DNS-записи;
- он не конвертирует произвольные схемы БД между приложениями;
- ClickHouse, InfluxDB, VictoriaMetrics и другие специализированные хранилища подключаются через `database.engine=custom` со штатными командами конкретной версии;
- сетевые настройки и firewall экспортируются как справочные данные и не накатываются автоматически;
- репетиция восстановления обязательна: наличие backup-файла не доказывает восстанавливаемость.
